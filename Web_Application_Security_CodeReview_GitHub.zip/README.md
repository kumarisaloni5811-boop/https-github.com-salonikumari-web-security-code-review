# Web Application Security Code Review

## Objective
A small self-created Flask application demonstrating a security-focused source-code review and remediation.

## Files
- `app.py` - remediated/secure demonstration application.
- `vulnerable_sample.py` - intentionally vulnerable training sample.
- `SECURITY_REVIEW.md` - detailed findings, severity and remediation.
- `REPORT.md` - submission report.
- `templates/` - application pages.
- `requirements.txt` - dependencies.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

Demo login: `demo` / `DemoPass123`

## Security note
This project is for an authorized educational code-review task. Do not test or deploy the vulnerable sample against systems you do not own or have permission to assess. Never upload real passwords, API keys, tokens, or private credentials.
