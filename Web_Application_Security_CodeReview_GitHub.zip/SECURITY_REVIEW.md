# Security Review

Scope: self-created training application only.

| ID | Issue | Severity | Remediation |
|---|---|---|---|
| SEC-01 | Unsafe SQL construction | High | Parameterized queries |
| SEC-02 | Unsafe HTML rendering | High | Template auto-escaping |
| SEC-03 | Plaintext password handling | High | Strong password hashing |
| SEC-04 | Missing authentication | High | Require login for protected routes |
| SEC-05 | Improper access control | High | Enforce role and ownership checks |
| SEC-06 | Hard-coded secret | Medium | Environment/secret manager |
| SEC-07 | Debug mode | Medium | Disable debug in production |
| SEC-08 | Missing security headers | Low | Add baseline browser headers |

## SEC-01: SQL injection
The vulnerable sample builds SQL with string interpolation. Untrusted input should never be concatenated into SQL. The secure application uses `?` parameters.

## SEC-02: Unsafe output handling
The vulnerable sample inserts untrusted values into HTML. The secure application uses Jinja templates with auto-escaping.

## SEC-03: Password security
Passwords must not be stored or compared as plaintext. The secure application uses Werkzeug password hashing and verification.

## SEC-04: Authentication
Protected resources must verify that a user is logged in. The secure application checks session state before serving notes and admin data.

## SEC-05: Authorization
Authentication is not enough. The secure application checks both the user's role and note ownership.

## SEC-06: Secrets
Hard-coded secrets can leak through source control. The secure application reads `SECRET_KEY` from an environment variable, with a development fallback.

## SEC-07: Error/debug handling
Debug mode is disabled in the application entry point.

## SEC-08: Security headers
The application adds Content-Security-Policy, X-Content-Type-Options, X-Frame-Options and Referrer-Policy.
