from flask import Flask, render_template, request, redirect, url_for, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-in-production")
DB = "app.db"

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, role TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS notes(
        id INTEGER PRIMARY KEY, title TEXT, body TEXT, owner_id INTEGER)""")
    if not con.execute("SELECT 1 FROM users WHERE username=?", ("demo",)).fetchone():
        con.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                    ("demo", generate_password_hash("DemoPass123"), "user"))
        con.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                    ("admin", generate_password_hash("AdminPass123"), "admin"))
        con.execute("INSERT INTO notes(title,body,owner_id) VALUES(?,?,?)",
                    ("Security Review Demo", "This note is protected by authentication and ownership checks.", 1))
    con.commit()
    con.close()

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'"
    return response

def login_required():
    return "user_id" in session

@app.route("/")
def home():
    return render_template("index.html", user=session.get("username"))

@app.route("/login", methods=["GET","POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if not (1 <= len(username) <= 50 and 8 <= len(password) <= 128):
            error = "Please enter valid credentials."
        else:
            con = db()
            user = con.execute(
                "SELECT id, username, password_hash, role FROM users WHERE username=?",
                (username,)).fetchone()
            con.close()
            if user and check_password_hash(user["password_hash"], password):
                session.clear()
                session["user_id"] = user["id"]
                session["username"] = user["username"]
                session["role"] = user["role"]
                return redirect(url_for("home"))
            error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/note/<int:note_id>")
def note(note_id):
    if not login_required():
        return redirect(url_for("login"))
    con = db()
    note = con.execute("SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
    con.close()
    if not note:
        abort(404)
    if note["owner_id"] != session["user_id"] and session.get("role") != "admin":
        abort(403)
    return render_template("note.html", note=note)

@app.route("/admin")
def admin():
    if not login_required() or session.get("role") != "admin":
        abort(403)
    con = db()
    users = con.execute("SELECT id, username, role FROM users").fetchall()
    con.close()
    return render_template("admin.html", users=users)

if __name__ == "__main__":
    init_db()
    app.run(debug=False)
