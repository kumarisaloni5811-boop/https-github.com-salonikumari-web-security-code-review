# INTENTIONALLY VULNERABLE TRAINING SAMPLE
# Review only this self-created sample. Do not deploy it.

SECRET = "hard-coded-secret"

def unsafe_login(db, username, password):
    # ISSUE: SQL injection risk and plaintext password handling
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    return db.execute(query).fetchone()

def unsafe_note(title, body):
    # ISSUE: untrusted HTML is returned without escaping
    return f"<h1>{title}</h1><p>{body}</p>"

def unsafe_admin():
    # ISSUE: no authentication or authorization check
    return "Sensitive admin data"

# ISSUE: production debug mode should not be enabled.
DEBUG = True
