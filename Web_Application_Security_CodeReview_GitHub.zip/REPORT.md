# Web Application Security Code Review Report

## 1. Objective
Review a small intentionally vulnerable/self-created web application, identify common security weaknesses and provide practical remediation.

## 2. Scope
Only the self-created training application was reviewed. No third-party systems were assessed.

## 3. Technology
Python, Flask, SQLite, Jinja templates and Werkzeug password hashing.

## 4. Findings
Eight issues were documented:
1. Unsafe SQL construction — High
2. Unsafe HTML rendering — High
3. Plaintext password handling — High
4. Missing authentication — High
5. Improper access control — High
6. Hard-coded secret — Medium
7. Debug mode — Medium
8. Missing security headers — Low

## 5. Remediation
The secure application uses parameterized queries, password hashing, authentication checks, role/ownership checks, auto-escaping, environment-based secrets, disabled debug mode and security headers.

## 6. Verification
The main functionality can be demonstrated locally through the login page, protected note page and admin page.

## 7. Limitations
This is a focused source-code review, not a complete penetration test. Production deployment, dependency auditing, TLS, CSRF protection, rate limiting and monitoring should be reviewed separately.
